-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         8.0.30 - MySQL Community Server - GPL
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para mapplebarbershop
CREATE DATABASE IF NOT EXISTS `mapplebarbershop` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `mapplebarbershop`;

-- Volcando estructura para tabla mapplebarbershop.agenda
CREATE TABLE IF NOT EXISTS `agenda` (
  `id_agenda` int NOT NULL AUTO_INCREMENT,
  `fecha` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `nombre` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `telefono` varchar(50) DEFAULT NULL,
  `estado` enum('pendiente','hecha','cancelada') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`id_agenda`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla mapplebarbershop.agenda: ~7 rows (aproximadamente)
INSERT INTO `agenda` (`id_agenda`, `fecha`, `hora`, `nombre`, `telefono`, `estado`) VALUES
	(1, '2024-04-25', '07:56:00', 'paco', '44939583', 'pendiente'),
	(2, '2024-04-06', '19:52:00', 'angel', '699304876', 'cancelada'),
	(4, '2024-04-30', '14:30:00', 'David', '618123647', 'pendiente'),
	(5, '2024-04-22', '11:30:00', 'jesus', '61858785', 'pendiente'),
	(6, '2024-04-27', '01:33:00', 'Sergio', '6182610523', 'pendiente'),
	(9, '2024-04-23', '22:59:00', 'David', '8877555668', 'hecha'),
	(10, '2024-04-30', '15:03:00', 'Edwin', '6188111111', 'hecha');

-- Volcando estructura para tabla mapplebarbershop.estilosbarba
CREATE TABLE IF NOT EXISTS `estilosbarba` (
  `id_barba` int NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `descripcion` varchar(50) DEFAULT NULL,
  `precio` int DEFAULT NULL,
  PRIMARY KEY (`id_barba`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla mapplebarbershop.estilosbarba: ~0 rows (aproximadamente)

-- Volcando estructura para tabla mapplebarbershop.estiloscorte
CREATE TABLE IF NOT EXISTS `estiloscorte` (
  `id_corte` int NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `descripcion` varchar(50) DEFAULT NULL,
  `precio` int DEFAULT NULL,
  PRIMARY KEY (`id_corte`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla mapplebarbershop.estiloscorte: ~0 rows (aproximadamente)

-- Volcando estructura para tabla mapplebarbershop.productos
CREATE TABLE IF NOT EXISTS `productos` (
  `id_producto` int NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `descripcion` varchar(50) DEFAULT NULL,
  `precio` int DEFAULT NULL,
  `cantidad` int DEFAULT NULL,
  PRIMARY KEY (`id_producto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla mapplebarbershop.productos: ~3 rows (aproximadamente)
INSERT INTO `productos` (`id_producto`, `nombre`, `descripcion`, `precio`, `cantidad`) VALUES
	(1, 'Spray Estefy', 'Spray para el cabello', 200, 5),
	(2, 'Cera cabello', 'Spray para el cabello', 150, 43),
	(3, 'Aceite p barba', 'Spray para el cabello', 180, 34);

-- Volcando estructura para tabla mapplebarbershop.usuarios
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id_user` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `email` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `phone` bigint DEFAULT NULL,
  `password` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `rol` enum('administrador','usuario_regular') NOT NULL DEFAULT 'usuario_regular',
  PRIMARY KEY (`id_user`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla mapplebarbershop.usuarios: ~6 rows (aproximadamente)
INSERT INTO `usuarios` (`id_user`, `name`, `email`, `phone`, `password`, `rol`) VALUES
	(1, 'Sergio', 'sergio_sesh@hotmail.com', 6182610523, 'asdasdasd', 'administrador'),
	(2, 'asdasd', 'sdas@asdas', 38599345920, 'fwfsdfsd', 'usuario_regular'),
	(3, 'Sergio', 'plon@si', 1234567890, 'oal', 'usuario_regular'),
	(4, 'David', 'david@unipoli', 6181112266, 'david', 'usuario_regular'),
	(5, 'Edu', 'odamrd@esencia.com', 6186666166, 'esencia', 'usuario_regular');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
