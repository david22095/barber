<?php
$servername="localhost";
$username="root";
$password="";
$database="mapplebarbershop";
$conn=new mysqli($servername,$username,$password,$database);
if ($conn->connect_error) {
	die ("Conexion fallida: " . $conn->connect_error);
}
//consulta para obtener los usuarios
$sql="SELECT nombre, precio FROM productos";
$result=$conn->query($sql);
//generar la tabla de usuarios con acciones de edición y de eliminación
if ($result->num_rows>0) {
	while ($row=$result->fetch_assoc()) {
		echo "<tr>
				<td>{$row['nombre']}</td>
				<td>{$row['precio']}</td>
			  </tr>";
	}
} else {
	echo "<tr><td colspan='7'>No hay usuarios</td></tr>";
}
$conn->close();
?>