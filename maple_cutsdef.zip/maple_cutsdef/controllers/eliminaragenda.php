<?php
$servername = 'localhost';
$username = 'root';
$password = "";
$database = "mapplebarbershop";
$conn = new mysqli($servername, $username, $password, $database);
if($conn->connect_error){
    diel("Conexión fallida: $conn->connect_error");
}
//Obtener datos del formulario del crud
$id_agenda = $_POST['id_agenda'];
//Consulta SQL para actualizar los datos en la row especificada
$sql = "DELETE FROM agenda WHERE id_agenda=$id_agenda";
if ($conn->query($sql) === TRUE) {
    echo "Registro eliminado correctamente";
} else {
    echo "Error al eliminar el registro: " . $conn->error;
}
$conn->close();
?>