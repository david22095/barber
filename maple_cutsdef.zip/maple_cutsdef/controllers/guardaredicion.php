<?php
$servername = 'localhost';
$username = 'root';
$password = "";
$database = "mapplebarbershop";
$conn = new mysqli($servername, $username, $password, $database);
if($conn->connect_error){
    diel("Conexión fallida: $conn->connect_error");
}
//Obtener datos del formulario del crud
$id_user = $_POST['id_user'];
$name = $_POST['name'];
$email = $_POST['email'];
$phone=$_POST['phone'];
$password = $_POST['password'];
$rol=$_POST['rol'];
//Consulta SQL para actualizar los datos en la row especificada
$sql = "UPDATE usuarios SET name='$name', email='$email', phone='$phone', password='$password', rol='$rol' WHERE id_user=$id_user";
if ($conn->query($sql) === TRUE) {
    echo "Registro actualizado correctamente";
} else {
    echo "Error al actualizar el registro: " . $conn->error;
}
$conn->close();
?>