<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$database = "mapplebarbershop";
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Conexion fallida: " . $conn->connect_error);
}
// Recibe los datos del formulario
$fecha = $_POST['fecha'];
$hora = $_POST['hora'];
$nombre = $_POST['nombre'];
$telefono = $_POST['telefono'];
$estado = 'pendiente';

// Prepara la consulta SQL para insertar la cita en la base de datos
$sql = "INSERT INTO agenda (fecha, hora, nombre, telefono, estado) VALUES ('$fecha', '$hora', '$nombre', '$telefono', '$estado')";

// Ejecuta la consulta SQL
if ($conn->query($sql) === TRUE) {
    //echo "Cita agendada correctamente";
    header("Location: ../agenda.html");
} else {
    echo "Error al agendar la cita: " . $conn->error;
}

// Cierra la conexión a la base de datos
$conn->close();
?>
