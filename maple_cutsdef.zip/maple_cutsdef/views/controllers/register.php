<?php
//include_once('conexion.php');
session_start();
//Base de datos
$servername = "localhost";
$username = "root";
$password = "";
$database = "mapplebarbershop";
//Crear una conexión
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Conexion fallida: " . $conn->connect_error);
}
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$password = $_POST['password'];
$rol='usuario_regular';
//insertar los valores dentro de la base de datos
$sqlinsert = "INSERT INTO
    usuarios (id_user, name, email, phone, password, rol)
    VALUES (NULL, '$name', '$email', '$phone', '$password', '$rol')";
// Verificacion de la insercion de datos
if($conn->query($sqlinsert) === TRUE){
    header("Location: ../../index.php");
} else {
    echo"Usuario registrado incorrectanente: " . $conn->error;
}
?>