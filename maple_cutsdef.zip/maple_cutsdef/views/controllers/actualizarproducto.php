<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$database = "mapplebarbershop";
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Conexion fallida: " . $conn->connect_error);
}
$productId = $_POST['productId'];
$quantity = $_POST['quantity'];

// Actualizar la cantidad del producto en la base de datos
$sql = "UPDATE productos SET cantidad = cantidad - $quantity WHERE id_producto = $productId";

if ($conn->query($sql) === TRUE) {
    echo "Cantidad actualizada correctamente";
} else {
    echo "Error al actualizar la cantidad: " . $conn->error;
}

// Cerrar conexión
$conn->close();
?>