<?php
$servername = 'localhost';
$username = 'root';
$password = "";
$database = "mapplebarbershop";
$conn = new mysqli($servername, $username, $password, $database);
if($conn->connect_error){
    diel("Conexión fallida: $conn->connect_error");
}
//Obtener datos del formulario del crud
$id_agenda = $_POST['id_agenda'];
$fecha = $_POST['fecha'];
$hora = $_POST['hora'];
$nombre=$_POST['nombre'];
$telefono = $_POST['telefono'];
$estado=$_POST['estado'];
//Consulta SQL para actualizar los datos en la row especificada
$sql = "UPDATE agenda SET fecha='$fecha', hora='$hora', nombre='$nombre', telefono='$telefono', estado='$estado' WHERE id_agenda=$id_agenda";
if ($conn->query($sql) === TRUE) {
    echo "Registro actualizado correctamente";
} else {
    echo "Error al actualizar el registro: " . $conn->error;
}
$conn->close();
?>