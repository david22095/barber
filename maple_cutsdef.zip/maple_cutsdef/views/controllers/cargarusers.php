<?php
$servername="localhost";
$username="root";
$password="";
$database="mapplebarbershop";
$conn=new mysqli($servername,$username,$password,$database);
if ($conn->connect_error) {
	die ("Conexion fallida: " . $conn->connect_error);
}
//consulta para obtener los usuarios
$sql="SELECT * FROM usuarios";
$result=$conn->query($sql);
//generar la tabla de usuarios con acciones de edición y de eliminación
if ($result->num_rows>0) {
	while ($row=$result->fetch_assoc()) {
		echo "<tr>
				<td>{$row['id_user']}</td>
				<td>{$row['name']}</td>
				<td>{$row['email']}</td>
				<td>{$row['phone']}</td>
				<td>{$row['password']}</td>
				<td>{$row['rol']}</td>
				<td>
					<button onclick='mostrarEditarUsuario({$row['id_user']}, \"{$row['name']}\", \"{$row['email']}\", {$row['phone']}, \"{$row['password']}\", \"{$row['rol']}\")'>Editar 
					</button>
					<button onclick='mostrarEliminarUsuario({$row['id_user']})'>Eliminar</button>
				</td>
			  </tr>";
	}
} else {
	echo "<tr><td colspan='7'>No hay usuarios</td></tr>";
}
$conn->close();
?>