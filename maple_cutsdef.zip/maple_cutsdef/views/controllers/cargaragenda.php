<?php
$servername="localhost";
$username="root";
$password="";
$database="mapplebarbershop";
$conn=new mysqli($servername,$username,$password,$database);
if ($conn->connect_error) {
	die ("Conexion fallida: " . $conn->connect_error);
}
//consulta para obtener los usuarios
$sql="SELECT * FROM agenda";
$result=$conn->query($sql);
//generar la tabla de usuarios con acciones de edición y de eliminación
if ($result->num_rows>0) {
	while ($row=$result->fetch_assoc()) {
		echo "<tr>
				<td>{$row['id_agenda']}</td>
				<td>{$row['fecha']}</td>
				<td>{$row['hora']}</td>
				<td>{$row['nombre']}</td>
				<td>{$row['telefono']}</td>
				<td>{$row['estado']}</td>
				<td>
					<button onclick='mostrarEditarUsuario({$row['id_agenda']}, \"{$row['fecha']}\", \"{$row['hora']}\", \"{$row['nombre']}\", \"{$row['telefono']}\", \"{$row['estado']}\")'>Editar 
					</button>
					<button onclick='mostrarEliminarUsuario({$row['id_agenda']})'>Eliminar</button>
				</td>
			  </tr>";
	}
} else {
	echo "<tr><td colspan='7'>No hay usuarios</td></tr>";
}
$conn->close();
?>