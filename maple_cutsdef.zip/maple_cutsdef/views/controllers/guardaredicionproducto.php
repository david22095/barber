<?php
$servername = 'localhost';
$username = 'root';
$password = "";
$database = "mapplebarbershop";
$conn = new mysqli($servername, $username, $password, $database);
if($conn->connect_error){
    diel("Conexión fallida: $conn->connect_error");
}
//Obtener datos del formulario del crud
$id_producto = $_POST['id_producto'];
$nombre = $_POST['nombre'];
$descripcion = $_POST['descripcion'];
$precio=$_POST['precio'];
$cantidad = $_POST['cantidad'];
//Consulta SQL para actualizar los datos en la row especificada
$sql = "UPDATE productos SET nombre='$nombre', descripcion='$descripcion', precio='$precio', cantidad='$cantidad', WHERE id_producto=$id_producto";
if ($conn->query($sql) === TRUE) {
    echo "Registro actualizado correctamente";
} else {
    echo "Error al actualizar el registro: " . $conn->error;
}
$conn->close();
?>