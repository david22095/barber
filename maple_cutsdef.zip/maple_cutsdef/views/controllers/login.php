<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$database = "mapplebarbershop";
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Conexion fallida: " . $conn->connect_error);
}
$email = $_POST['email'];
$password = $_POST['password'];
$sql = "SELECT id_user, email, password, rol FROM usuarios where email='$email' and password='$password' "; 
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $result_data = $result->fetch_assoc();
    $_SESSION['username'] = $result_data['username'];
    $_SESSION['email'] = $result_data['email'];
    $_SESSION['rol'] = $result_data['rol']; // Establecer el rol en la sesión
    header("Location: ../../index.php");
} else {
    echo "Error al iniciar sesion <a href='login.html'>Intente de nuevo</a>";
}
$conn->close();
?>