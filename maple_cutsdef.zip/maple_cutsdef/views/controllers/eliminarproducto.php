<?php
$servername = 'localhost';
$username = 'root';
$password = "";
$database = "mapplebarbershop";
$conn = new mysqli($servername, $username, $password, $database);
if($conn->connect_error){
    diel("Conexión fallida: $conn->connect_error");
}
//Obtener datos del formulario del crud
$id_producto = $_POST['id_producto'];
//Consulta SQL para actualizar los datos en la row especificada
$sql = "DELETE FROM productos WHERE id_producto=$id_producto";
if ($conn->query($sql) === TRUE) {
    echo "Registro eliminado correctamente";
} else {
    echo "Error al eliminar el registro: " . $conn->error;
}
$conn->close();
?>