<!DOCTYPE html>
<html>
<head>
    <title>Admin Users</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/views/css/Styles.css">
    <script src="https://kit.fontawesome.com/3dffc80d90.js" crossorigin="anonymous"></script>
</head>
<body>
    <header class="header">
        <div class="menu">
            <p>
              <img src="/views/img/menu.png" alt="menu">
            </p>
            <ul>
              <li><a href="../../index.php">HOME</a></li>
              <li><a href="adminproducts.php">PRODUCTS</a></li>
              <li><a href="adminagenda.php">SCHEDULES</a></li>
              <li><a href="../controllers/logout.php">LOG OUT</a></li>
            </ul>
        </div>
    
        <img class="imagen-centro" src="/views/img/logo1.png" alt="Descripción de la imagen centro">
        
        <a href="../../index.php">
            <img src="/views/img/home2.jpeg" alt="home" style="height: 30px; width: 30px; padding: 10px; top: 10px;">
        </a>
    </header>
    
    <h2>Productos</h2>
    <style>
        body {
            background-color: #HHHHHH;
        table {
            border-collapse: collapse;
            width: 100%;
            color: #fff;
        }

        th, td {
            border: 1px solid #fff;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #000;
        }

        tr:nth-child(even) {
            background-color: #333;
        }

        tr:nth-child(odd) {
            background-color: #444;
        }
    </style>
    <table id="usuariosTable" border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripcion</th>
                <th>Precio</th>
                <th>Cantidad</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php
                include_once('../controllers/cargarproducto.php');
            ?>
        </tbody>
    </table>
    <div id="modalEditar"  style="display: none;">
        <h3>Editar Productos</h3>
        <form id="mostrarEditarUsuario">
            ID: <span id="editId"></span>
            Nombre: <input type="text" id="editNombre">
            Descripcion:<input type="text" id="editDescripcion">
            Precio:<input type="text" id="editPrecio">
            Cantidad:<input type="text" id="editCantidad">
            <button type="button" onclick="guardarEdicion()">Guardar</button>
        </form>
    </div>
    <div id="mostrarEliminarUsuario" style="display: none;">
        <h3>Confirmar eliminación de producto</h3>
        <p>¿Está seguro de eliminar el producto?</p>
        <button type="button" onclick="eliminarUsuario()">Eliminar</button>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
            $.ajax({
                url:'../controllers/cargarproducto.php',
                type:'GET',
                success: function(response) {
                    $('#usuariosTable tbody').html(response);
                }
            });
        });
            function mostrarEditarUsuario(id_producto,nombre,descripcion,precio,cantidad) {
            document.getElementById('editId').innerText=id_producto;
            document.getElementById('editNombre').value=nombre;
            document.getElementById('editDescripcion').value=descripcion;
            document.getElementById('editPrecio').value=precio;
            document.getElementById('editCantidad').value=cantidad;
            //mostrar la ventana modal de edición
            document.getElementById('modalEditar').style.display='block';
        }
        function guardarEdicion() {
            var id_producto=document.getElementById('editId').innerText;
            var nombre=document.getElementById('editNombre').value;
            var descripcion=document.getElementById('editDescripcion').value;
            var precio=document.getElementById('editPrecio').value;
            var cantidad=document.getElementById('editCantidad').value;
            //Enviar los datos editados al servidor usando AJAX
            $.ajax({
                type: 'POST',
                url: '../controllers/guardaredicionproducto.php',
                //este archivo procesara la edicion en el servidor
                data: {
                    id_producto,
                    nombre,
                    descripcion,
                    precio,
                    cantidad,
                },
                success: function(response) {
                    alert('Producto editado correctamente');
                    document.getElementById('modalEditar').style.display='none';
                    //actualizar la lista de usuarios despues de la edicion
                    actualizarListaUsuarios();
                }
            });
        }
        function mostrarEliminarUsuario(id_producto){
            document.getElementById('editId').innerText = id_producto;
            document.getElementById('mostrarEliminarUsuario').style.display='block';
        }
        function eliminarUsuario(id_producto) {
            var id_producto=document.getElementById('editId').innerText;
            //Enviar los datos editados al servidor usando AJAX
            $.ajax({
                type: 'POST',
                url: '../controllers/eliminarproducto.php',
                //este archivo procesara la edicion en el servidor
                data: {
                    id_producto,
                },
                success: function(response) {
                    alert('Producto eliminado correctamente');
                    document.getElementById('mostrarEliminarUsuario').style.display='none';
                    //actualizar la lista de usuarios despues de la edicion
                    actualizarListaUsuarios();
                }
            });
        }
        function actualizarListaUsuarios() {
                //recargar la lista de usuarios después de la edición o eliminación
                $.ajax({
                    url:'../controllers/cargarproducto.php',
                    type: 'GET',
                    success: function(response) {
                        $('#usuariosTable tbody').html(response);
                    }
                });
            }
        
    </script>
</body>
</html>
