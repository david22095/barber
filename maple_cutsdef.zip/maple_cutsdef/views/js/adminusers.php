<!DOCTYPE html>
<html>
<head>
    <title>Admin Users</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/views/css/Styles.css">
    <script src="https://kit.fontawesome.com/3dffc80d90.js" crossorigin="anonymous"></script>
</head>
<body>
    <header class="header">
        <div class="menu">
            <p>
              <img src="/views/img/menu.png" alt="menu">
            </p>
            <ul>
              <li><a href="../../index.php">HOME</a></li>
              <li><a href="adminproductos.php">PRODUCTS</a></li>
              <li><a href="adminagenda.php">SCHEDULES</a></li>
              <li><a href="../controllers/logout.php">LOG OUT</a></li>
            </ul>
        </div>
    
        <img class="imagen-centro" src="/views/img/logo1.png" alt="Descripción de la imagen centro">
        
        <a href="../../index.php">
            <img src="/views/img/home2.jpeg" alt="home" style="height: 30px; width: 30px; padding: 10px; top: 10px;">
        </a>
    </header>
    
    <h2>Usuarios</h2>
    <style>
        body {
            background-color: #HHHHHH;
        table {
            border-collapse: collapse;
            width: 100%;
            color: #fff;
        }

        th, td {
            border: 1px solid #fff;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #000;
        }

        tr:nth-child(even) {
            background-color: #333;
        }

        tr:nth-child(odd) {
            background-color: #444;
        }
    </style>
    <table id="usuariosTable" border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Password</th>
                <th>Rol</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php
                include_once('../controllers/cargarusers.php');
            ?>
        </tbody>
    </table>
    <div id="modalEditar"  style="display: none;">
        <h3>Editar Usuarios</h3>
        <form id="mostrarEditarUsuario">
            ID: <span id="editId"></span>
            Nombre: <input type="text" id="editName">
            Email:<input type="text" id="editEmail">
            Phone:<input type="text" id="editPhone">
            Password:<input type="text" id="editPassword">
            Rol:<input type="password" id="editRol">
            <button type="button" onclick="guardarEdicion()">Guardar</button>
        </form>
    </div>
    <div id="mostrarEliminarUsuario" style="display: none;">
        <h3>Confirmar eliminación de usuario</h3>
        <p>¿Está seguro de eliminar el usuario seleccionado? Esta acción no se puede revertir.</p>
        <button type="button" onclick="eliminarUsuario()">Eliminar</button>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
            $.ajax({
                url:'../controllers/cargarusers.php',
                type:'GET',
                success: function(response) {
                    $('#usuariosTable tbody').html(response);
                }
            });
        });
            function mostrarEditarUsuario(id_user,name,email,phone,password,rol) {
            document.getElementById('editId').innerText=id_user;
            document.getElementById('editName').value=name;
            document.getElementById('editEmail').value=email;
            document.getElementById('editPhone').value=phone;
            document.getElementById('editPassword').value=password;
            document.getElementById('editRol').value=rol;
            //mostrar la ventana modal de edición
            document.getElementById('modalEditar').style.display='block';
        }
        function guardarEdicion() {
            var id_user=document.getElementById('editId').innerText;
            var name=document.getElementById('editName').value;
            var email=document.getElementById('editEmail').value;
            var phone=document.getElementById('editPhone').value;
            var password=document.getElementById('editPassword').value;
            var rol=document.getElementById('editRol').value;
            //Enviar los datos editados al servidor usando AJAX
            $.ajax({
                type: 'POST',
                url: '../controllers/guardaredicion.php',
                //este archivo procesara la edicion en el servidor
                data: {
                    id_user,
                    name,
                    email,
                    phone,
                    password,
                    rol,
                },
                success: function(response) {
                    alert('Usuario editado correctamente');
                    document.getElementById('modalEditar').style.display='none';
                    //actualizar la lista de usuarios despues de la edicion
                    actualizarListaUsuarios();
                }
            });
        }
        function mostrarEliminarUsuario(id_user){
            document.getElementById('editId').innerText = id_user;
            document.getElementById('mostrarEliminarUsuario').style.display='block';
        }
        function eliminarUsuario(id_user) {
            var id_user=document.getElementById('editId').innerText;
            //Enviar los datos editados al servidor usando AJAX
            $.ajax({
                type: 'POST',
                url: '../controllers/eliminarusuario.php',
                //este archivo procesara la edicion en el servidor
                data: {
                    id_user,
                },
                success: function(response) {
                    alert('Usuario eliminado correctamente');
                    document.getElementById('mostrarEliminarUsuario').style.display='none';
                    //actualizar la lista de usuarios despues de la edicion
                    actualizarListaUsuarios();
                }
            });
        }
        function actualizarListaUsuarios() {
                //recargar la lista de usuarios después de la edición o eliminación
                $.ajax({
                    url:'../controllers/cargarusers.php',
                    type: 'GET',
                    success: function(response) {
                        $('#usuariosTable tbody').html(response);
                    }
                });
            }
        
    </script>
</body>
</html>
