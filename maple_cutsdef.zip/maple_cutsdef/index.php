<!DOCTYPE html>
<html lang="en">
<head>
    <title>Mapple Cuts</title>
    <link rel="stylesheet" href="/views/css/Styles.css">
    <script src="https://kit.fontawesome.com/3dffc80d90.js" crossorigin="anonymous"></script>
</head>
<body>

  <header class="header">

    <div class="menu">
        <p>
          <img src="/views/img/menu.png" alt="menu">
        </p>
        <ul>
          <li><a href="/views/product.html">PRODUCTOS</a></li>
          <li><a href="/views/Servicios_cortes/index.html">ESTILOS</a></li>
          <li><a href="/views/agenda.html">AGENDAR</a></li>
          <?php
            session_start();
            if(isset($_SESSION['rol']) && $_SESSION['rol'] === 'administrador') {
          echo '<li><a href="views/js/adminusers.php">ADMIN</a></li>';
          }
          ?>
          <li><a href="/views/controllers/logout.php">SALIR</a></li>
        </ul>
      </div>
    
    <img class="imagen-centro" src="/views/img/logo1.png" alt="Descripción de la imagen centro">
    
    <a href="/index.html">
        <img src="/views/img/home2.jpeg" alt="home" style="height: 30px; width: 30px; padding: 10px; top: 10px;">
    </a>

  </header>

    <section>  
        <div class="fondo">          
            <div class="f-txt">
                <h1 style="color: white;">CORTE Y DISTINCION</h1>
            </div>
        </div>                                                                                                                                                              
    </section>

    <section>
        <div class="space">
            <h1 class="title">SALON DE PELUQUERIA Y <span style="color: red;">BARBERIA</span></h1>
            
            <h3 class="lista">CORTE DE PELO</h3>
            <h3 class="lista">ESTILOS DE BARBA</h3>
            <h3 class="lista">TEÑIDO DE BARBA</h3>
            <h3 class="lista">LIMPIEZA FACIAL</h3>
            <h3 class="lista">PERMANENTE / ONDULADO</h3>
            <h3 class="lista">DELINEADO DE CEJA</h3>
            <h3 class="lista">PLANCHADO</h3>
            <h3 class="lista">MAQUILLAJE</h3>

            <a href="/views/Servicios_cortes/index.html">
                <button>
                    <p>MAS INFO</p>
                </button>
            </a>
        </div>
    </section>

    <section>
        <div class="fondo-1";">
          <a href="views/agenda.html">
            <button>
              <p>AGENDA SERVICIO</p>
            </button>
          </a>
        </div>     
    </section>

    <section>
        <div class="space">
            <h1>NUESTRO</h1>
            <h1 style="color: red; margin-bottom: 2%;">HORARIO</h1>
            <h2 style="color: red;">LUNES A VIERNES</h2>
            <h2 style="margin-bottom: 2%;">12:00 PM A 7:00 PM</h2>
            <h2 style="color: red;">SABADO A DOMINGO</h2>
            <h2>11:00 AM A 3:00 PM</h2>
        </div>
    </section>
    <div style="background-color: red">
        <h2 style="padding: 20px; color: white;">PRODUCTOS DE CALIDAD</h2>
        <div class="carrusel">
            
          <div class="elemento"> 
            <div class="cards-carrusel">
              <div>
                <img src="/views/img/product1.png" alt="img" class="imgcard">
              </div>
              <div>
                <p style="color: white;">Spray para el cabello</p>
              </div>
            </div>
          </div>
          <div class="elemento">
            <div class="cards-carrusel">
              <div>
                <img src="/views/img/product2.png" alt="img" class="imgcard">
              </div>
              <div>
                <p style="color: white;">Spray para el cabello</p>
              </div>
            </div>
          </div>
          <div class="elemento">
            <div class="cards-carrusel">
              <div>
                <img src="/views/img/product3.png" alt="img" class="imgcard">
              </div>
              <div>
                <p style="color: white;">Spray para el cabello</p>
              </div>
            </div>
          </div>
          <div class="elemento">
            <div class="cards-carrusel">
                <div>
                  <img src="/views/img/product3.png" alt="img" class="imgcard">
                </div>
                <div>
                  <p style="color: white;">Spray para el cabello</p>
                </div>
              </div>
          </div>
        </div>
      </div>

    <section>
        <div class="space">
            <a href="views/product.html">
                <button class="btm-2">
                    <p>VER TIENDA</p>
                </button>
            </a>

            <h2>NUESTRA</h2>
            <h2 style="color: red;">UBICACION</h2>
        </div>
    </section>
    
    <section>
        <div class="f-n">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d503.04626846741047!2d-104.59926302582294!3d24.050610808891783!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x869bb739dbcc58f3%3A0xc6fe71500e77c82c!2sMapple%20barbershop!5e0!3m2!1ses!2smx!4v1707845197669!5m2!1ses!2smx" width="1300" height="400" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </section>
    
    <footer>
        
        <h3>WHATSAPP <span><i class="fa-brands fa-whatsapp"></i></span></h3>
        <h3 style="top: -30px; position: relative;">618-123-45-67</h3>
        <h3>INSTAGRAM <span><i class="fa-brands fa-instagram"></i></span></h3>
        <h3 style="top: -30px; position: relative;" >MAPPLE_CUTS</h3>

    </footer>
    
</body>
</html>